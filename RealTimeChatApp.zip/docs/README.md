# RealTimeChatApp

Detailed documentation for the project.
